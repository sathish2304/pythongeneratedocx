import time
import json
import boto3
from docx import Document
from docx.text.run import Font, Run
 
def lambda_handler(event,context):
    outputuri=event['outputuri'] 
    print(outputuri)
    jobname=outputuri.split('/')[-1].split('.json')[0]
    document = Document()
    f = open('/tmp/output.json', 'w')
    f.close()
    nl = "\n"
    para=''
    outputfile=outputuri.split("/")[-1]
    s3bucket=outputuri.split("/")[-2]
    s3 = boto3.resource('s3')
    s3.meta.client.download_file(s3bucket,outputfile,'/tmp/output.json')
    with open('/tmp/output.json', 'r') as myfile:
     trans_out=myfile.read()
    trans_out_json=json.loads(trans_out)
    results=trans_out_json['results']
    transcript=results['transcripts']
    speaker_labels=results['speaker_labels']
    items=results['items']
    spk_label_segments=speaker_labels['segments']
    for obj in spk_label_segments:
     start_time=obj['start_time']
     start_time=float(start_time)
     end_time=obj['end_time']
     end_time=float(end_time)
     item=obj['items']
     item_length=len(item)
     cnt=item_length - 1
     if cnt >= 1 :
      item_end_time=item [cnt] ['end_time']
      item_end_time=float(item_end_time)
      if item_end_time > end_time:
       end_time=item_end_time
      speaker_label=obj['speaker_label']
      #sentance=(speaker_label + ":")
      p = document.add_paragraph(speaker_label + " : ")
      for words in items:
       w_type=words['type']
       if (w_type == "pronunciation"):
        w_start_time=words['start_time']
        w_start_time=float(w_start_time)
        w_end_time=words['end_time']
        w_end_time=float(w_end_time)
        alt=words['alternatives']
        confidence_pro=alt[0]['confidence']
        confidence_pro=float(confidence_pro)
        content_pro=alt[0]['content']
        if all( [ w_start_time >= start_time , w_end_time <= end_time ] ):
         if confidence_pro < 0.5000:
          #content_pro=(bcolors.FAIL + content_pro + bcolors.ENDC)
          p.add_run(content_pro).bold = True	
          p.add_run(" ")
         elif confidence_pro < 0.8000:
          #content_pro=(bcolors.WARNING + content_pro + bcolors.ENDC)
          p.add_run(content_pro).underline = True
          p.add_run(" ")
         else:
          #sentance=(sentance + " " + content_pro)
          p.add_run(content_pro)
          p.add_run(" ")
       if ( w_end_time >= end_time ):
         break
       elif ( w_start_time <= start_time ):
         continue
       elif (w_type == "punctuation"):

        alt_pun=words['alternatives']
        content_pun=alt_pun[0]['content']
        #sentance=(sentance + content_pun)
        p.add_run(content_pun)
        p.add_run(" ")
      document.save('/tmp/' + jobname + '-transcribe.docx')
    s3 = boto3.client('s3')
    with open('/tmp/' + jobname + '-transcribe.docx','rb') as data: 
     s3.upload_fileobj(data,s3bucket, 'output/' + jobname + '-transcribe.docx')
    return 
